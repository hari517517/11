﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace AsyncPgm
{
    class Program
    {
        [STAThread]
        static void Main()
        {
            var demo = new AsyncAwaitDemo();
            Console.WriteLine("Calling Synchronous Method");
            //Apply a breakpoint in the Method call and check the execution sequence.
            demo.DoStuff1();
            //demo.DoStuff();
            Console.WriteLine("Doing Stuff on the Main Thread...................");
            Console.ReadKey();
        }
    }

    public class AsyncAwaitDemo
    {

        public async void DoStuff1()
        {

          await  Task.Run(new Action(LongRunningOperation));
            Console.WriteLine("New Thread");

        }

        //Synchronous Method Call
        public  void DoStuff()
        {
            
            Task.Run(new Action(LongRunningOperation));
            Console.WriteLine("New Thread");
    
        }

        private static void LongRunningOperation()
        {
            Thread.Sleep(3000);
            Console.WriteLine("Processed");
        }
    }
}
