﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskandAsyncDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch sw = Stopwatch.StartNew();
            sw.Start();

            //////Serial Way
            //int carid = BookCar();
            //int hotelid = BookHotel();
            //int plainid = BookPlain();
            //Console.WriteLine("Finished All Booking..Car Id {0}, Hotel Id {1}, Plain Id {2}", carid, hotelid, plainid);


            //Parallel Way
            Task<int> hotelTask = Task.Factory.StartNew<int>(BookHotel);
            Task<int> carTask = Task.Factory.StartNew<int>(BookCar);
            Task<int> plainTask = Task.Factory.StartNew<int>(BookPlain);
            Console.WriteLine("Finished Booking..Car Id {0}, Hotel Id {1}, Plain Id {2}", carTask.Result, hotelTask.Result, plainTask.Result);

            //Task hotelFollowup = hotelTask.ContinueWith(
            //    taskPrev => Console.WriteLine("Sending Mail to followup Booking with id {0}", taskPrev.Result)
            //    );
            //hotelFollowup.Wait();

            //Task.WaitAll(carTask, hotelTask, plainTask);


            Console.WriteLine("Finished in {0} Sec", sw.ElapsedMilliseconds / 1000.0);
            Console.ReadKey();
        }

        static Random rand = new Random();
        
        private static int BookPlain()
        {
            Console.WriteLine("Booking Plane..!!");
            Thread.Sleep(5000);
            Console.WriteLine("Booking Plane..Done!!");
            return rand.Next(100);

        }

        private static int BookHotel()
        {
            Console.WriteLine("Booking Hotel..!!");
            Thread.Sleep(8000);
            Console.WriteLine("Booking Hotel..Done!!");
            return rand.Next(100);
        }

        private static int BookCar()
        {
            Console.WriteLine("Booking Car..!!");
            Thread.Sleep(3000);
            Console.WriteLine("Booking Car..Done!!");
            return rand.Next(100);
        }
    }
}
