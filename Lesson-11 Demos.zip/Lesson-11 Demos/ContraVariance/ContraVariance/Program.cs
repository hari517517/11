﻿/*covariance means we can substitute derived type in place of base type. 
 * Contravariance means we can substitute base class in place of derived class*/
//Contravariance is the opposite to covariance, and allows you to
//use a more general class when a specific class should be used. 
//Contravariance uses the In modifier to
//specify the parameter can only occur in the input position.
//public interface IComparer<in T>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace ContraVariance
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeComparer empcomparer = new EmployeeComparer();

            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee(101, 20));
            emplist.Add(new Employee(102, 40));
            emplist.Add(new Employee(103, 60));
            emplist.Add(new Employee(104, 10));
            emplist.Add(new Employee(105, 30));

            //Works
            emplist.Sort(empcomparer);

            List<Manager> managerlist = new List<Manager>();
            managerlist.Add(new Manager(202, 20, 10000));
            managerlist.Add(new Manager(203, 40, 10000));
            managerlist.Add(new Manager(204, 30, 10000));
            managerlist.Add(new Manager(205, 10, 10000));

            //Doesn't work prior to .net 4
            managerlist.Sort(empcomparer);

            managerlist.ForEach(e => Console.WriteLine(e.EmployeeId.ToString() + "-" + e.DepartmentId.ToString()));

            Console.ReadKey();
        }
    }
    public class Employee
    {
        public int EmployeeId { get; set; }
        public int DepartmentId { get; set; }
        public Employee()
        {
        }
        public Employee(int eid, int deptid)
        {
            EmployeeId = eid;
            DepartmentId = deptid;
        }
    }
    public class Manager : Employee
    {
        public double Perks { get; set; }
        public Manager()
        {
        }
        public Manager(int eid, int deptid, double perks)
            : base(eid, deptid)
        {
            Perks = perks;
        }
    }

    public class EmployeeComparer : IComparer<Employee>
    {

        public int Compare(Employee x, Employee y)
        {
            if (x.DepartmentId > y.DepartmentId) return 1;
            if (x.DepartmentId == y.DepartmentId) return 0;
            return -1;
        }
    }
}
